Locales = Locales or {}

Locales['en'] = {
    menu_title = "👕 Clothing Options",
    try_clothes = "🧥 Try on Clothes",
    try_clothes_desc = "Use appearance editor",
    finish_pay = "💾 Finish & Pay",
    finish_pay_desc = "Save outfit & checkout",
    paid_success = "You paid $%d for your outfit!",
    paid_error = "Not enough cash!"
}
--[[

    Rebel Clothing Store