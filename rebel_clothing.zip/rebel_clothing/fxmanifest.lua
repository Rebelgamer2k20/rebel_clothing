fx_version 'cerulean'
game 'gta5'

name "rebel_clothing"
description "Clothing for QBCORE"
author "Rebelgamer2k20"
version "1.0.0.0"
lua54 'yes'
shared_script '@qb-core/shared/locale.lua'
shared_script '@qb-core/shared/locale.lua'
shared_script 'shared/config.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'


escrow_ignore {
    'config.lua'
}